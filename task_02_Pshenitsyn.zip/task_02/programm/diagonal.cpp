//------------------------------------------------------------------------------
// diagonal.cpp - содержит реализацию методов
// диагональной матрицы
//------------------------------------------------------------------------------

#include "diagonal.h"

//------------------------------------------------------------------------------
// Ввод параметров диагональной матрицы из потока
void Diagonal::In(FILE *file) {
    fscanf(file, "%d", &n);
    data = new double[n];
    for (int i = 0; i < n; ++i) {
        fscanf(file, "%lf", &data[i]);
    }
}

// Случайный ввод параметров диагональной матрицы
void Diagonal::InRnd() {
    n = Random() % 10 + 1;
    data = new double[n];
    for (int i = 0; i < n; ++i) {
        data[i] = Random();
    }
}

//------------------------------------------------------------------------------
// Вывод параметров диагональной матрицы в поток
void Diagonal::Out(FILE *file) {
    fprintf(file, "%s", "It is Diagonal matrix: size = ");
    fprintf(file, "%d", n);
    fprintf(file, "%s", ". Average = ");
    fprintf(file, "%lf\n", Average());
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < i; ++j) {
            fprintf(file, "%s", " ");
        }
        fprintf(file, "%.2lf\n", data[i]);
    }
}

//------------------------------------------------------------------------------
// Вычисление среднего арифметического диагональной матрицы
double Diagonal::Average() {
    double s = 0.0;
    for (int i = 0; i < n; ++i) {
        s += data[i];
    }
    return s / n;
}

Diagonal::~Diagonal() {
    delete[] data;
}
