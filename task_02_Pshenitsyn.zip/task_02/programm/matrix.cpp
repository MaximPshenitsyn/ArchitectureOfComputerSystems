//------------------------------------------------------------------------------
// matrix.cpp - содержит процедуры связанные с обработкой квадратной матрицы
// и создания произвольной матрицы
//------------------------------------------------------------------------------

#include "matrix.h"
#include "low.h"
#include "diagonal.h"
#include "normal.h"

//------------------------------------------------------------------------------
// Ввод параметров обобщенной квадратной матрицы из файла
Matrix* Matrix::StaticIn(FILE *file) {
    Matrix *sp = nullptr;
    int k;
    fscanf(file, "%d", &k);
    switch(k) {
        case 1:
            sp = new Normal;
            break;
        case 2:
            sp = new Diagonal;
            break;
        case 3:
            sp = new Low;
            break;
        default:
            sp = nullptr;
    }
    sp->In(file);
    return sp;
}

// Случайный ввод обобщённой квадратной матрицы
Matrix* Matrix::StaticInRnd() {
    Matrix *sp = nullptr;
    auto k = rand() % 3 + 1;
    switch(k) {
        case 1:
            sp = new Normal;
            break;
        case 2:
            sp = new Diagonal;
            break;
        case 3:
            sp = new Low;
            break;
        default:
            sp = nullptr;
    }
    sp->InRnd();
    return sp;
}







