//------------------------------------------------------------------------------
// container_Constr.cpp - содержит функции обработки контейнера
//------------------------------------------------------------------------------

#include "container.h"

Container::Container(): len{0} {}

Container::~Container() {
    Clear();
}

//------------------------------------------------------------------------------
// Очистка контейнера от элементов (освобождение памяти)
void Container::Clear() {
    for(int i = 0; i < len; i++) {
        delete cont[i];
    }
    len = 0;
}

//------------------------------------------------------------------------------
// Ввод содержимого контейнера из указанного потока
void Container::In(FILE *file) {
    while(!feof(file)) {
        if((cont[len] = Matrix::StaticIn(file)) != nullptr) {
            len++;
        }
    }
    len = len == 0 ? len : len - 1;
    fclose(file);
}

//------------------------------------------------------------------------------
// Случайный ввод содержимого контейнера
void Container::InRnd(int size) {
    while(len < size) {
        if((cont[len] = Matrix::StaticInRnd()) != nullptr) {
            len++;
        }
    }    
}

//------------------------------------------------------------------------------
// Вывод содержимого контейнера в указанный поток
void Container::Out(FILE *file) {
    QSort(cont, 0, len - 1);
    fprintf(file, "%s", "Container contains ");
    fprintf(file, "%d", len);
    fprintf(file, "%s", " elements.\n");
    for(int i = 0; i < len; i++) {
        fprintf(file, "%d", i);
        fprintf(file, "%s", ": ");
        cont[i]->Out(file);
    }
}

//------------------------------------------------------------------------------
// Вычисление суммы периметров всех фигур в контейнере
double Container::AverageOfAll() {
    double sum = 0.0;
    for(int i = 0; i < len; i++) {
        sum += cont[i]->Average();
    }
    return sum / len;
}

//------------------------------------------------------------------------------
// Быстрая сортировка контейнера
void Container::QSort(Matrix *arr[], int l, int r) {
    double mid = arr[l + 1]->Average();
    int i = l;
    int j = r;

    while (i <= j){
        while (arr[i]->Average() < mid) i++;
        while (arr[j]->Average() > mid) j--;
        if (i <= j){
            swap(arr[i], arr[j]);
            i++;
            j--;
        }
    }
    if (i < r) QSort(arr, i, r);

    if (l < j) QSort(arr, l, j);
}



