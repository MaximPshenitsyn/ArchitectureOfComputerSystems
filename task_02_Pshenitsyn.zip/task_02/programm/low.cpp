//------------------------------------------------------------------------------
// low.cpp - содержит реализацию методов
// нижнетреугольной матрицы
//------------------------------------------------------------------------------

#include "low.h"

//------------------------------------------------------------------------------
// Ввод параметров нижнетреугольной матрицы из файла
void Low::In(FILE *file) {
    fscanf(file, "%d", &n);
    array_size = (n * (n + 1)) / 2;
    data = new double[array_size];
    for (int i = 0; i < array_size; ++i) {
        fscanf(file, "%lf", &data[i]);
    }
}

// Случайный ввод параметров нижнетреугольной матрицы
void Low::InRnd() {
    n = Random() % 10 + 1;
    array_size = (n * (n + 1)) / 2;
    data = new double[array_size];
    for (int i = 0; i < array_size; ++i) {
        data[i] = Random();
    }
}

//------------------------------------------------------------------------------
// Вывод параметров нижнетреугольной матрицы в форматируемый поток
void Low::Out(FILE *file) {
    fprintf(file, "%s", "It is Low matrix: size = ");
    fprintf(file, "%d", n);
    fprintf(file, "%s", ". Average = ");
    fprintf(file, "%lf\n", Average());
    int j = 0, cnt = 1;
    for (int i = 0; i < array_size; ++i) {
        if (j == cnt) {
            fprintf(file, "%s", "\n");
            j = 0;
            cnt++;
        }
        fprintf(file, "%.2lf ", data[i]);
        ++j;
    }
    fprintf(file, "%s", "\n");
}

//------------------------------------------------------------------------------
// Вычисление среднего арифметического нижнетреугольной матрицы
double Low::Average() {
    double s = 0.0;
    for (int i = 0; i < array_size; ++i) {
        s += data[i];
    }
    return s / array_size;
}

Low::~Low() {
    delete[] data;
}


