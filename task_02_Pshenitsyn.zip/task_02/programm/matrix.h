#ifndef __matrix__
#define __matrix__

//------------------------------------------------------------------------------
// matrix.h - содержит описание обобщающей матрицы,
//------------------------------------------------------------------------------

#include <fstream>
#include <stdio.h>
#include <stdlib.h>
#include "rnd.h"
using namespace std;

//------------------------------------------------------------------------------
// структура, обобщающая все имеющиеся матрицы
class Matrix {
protected:
    int n;
public:
    // virtual ~Matrix();
    // Ввод обобщенной матрицы
    static Matrix *StaticIn(FILE *file);
    // Виртуальный метод ввода обобщенной матрицы
    virtual void In(FILE *file) = 0;
    // Случайный ввод обобщенной матрицы
    static Matrix *StaticInRnd();
    // Виртуальный метод ввода случайной матрицы
    virtual void InRnd() = 0;
    // Вывод обобщенной матрицы
    virtual void Out(FILE *file) = 0;
    // Вычисление среднего значения обобщенной матрицы
    virtual double Average() = 0;
};

#endif
