//------------------------------------------------------------------------------
// normal.cpp - содержит реализацию методов
// квадратной матрицы
//------------------------------------------------------------------------------

#include "normal.h"

//------------------------------------------------------------------------------
// Ввод параметров квадратной матрицы из файла
void Normal::In(FILE *file) {
    fscanf(file, "%d", &n);
    data = new double * [n];
    for (int i = 0; i < n; ++i) {
        data[i] = new double[n];
        for (int j = 0; j < n; ++j) {
            fscanf(file, "%lf", &data[i][j]);
        }
    }
}

// Случайный ввод параметров квадратной матрицы
void Normal::InRnd() {
    n = Random() % 10 + 1;
    data = new double * [n];
    for (int i = 0; i < n; ++i) {
        data[i] = new double[n];
        for (int j = 0; j < n; ++j) {
            data[i][j] = Random();
        }
    }
}

//------------------------------------------------------------------------------
// Вывод параметров квадратной матрицы в форматируемый поток
void Normal::Out(FILE *file) {
    fprintf(file, "%s", "It is Square matrix: size = ");
    fprintf(file, "%d", n);
    fprintf(file, "%s", ". Average = ");
    fprintf(file, "%lf\n", Average());
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            fprintf(file, "%.2lf ", data[i][j]);
        }
        fprintf(file, "%s", "\n");
    }
}

//------------------------------------------------------------------------------
// Вычисление среднего арифметического квадратной матрицы
double Normal::Average() {
    double s = 0.0;
    for (int i = 0; i < n; ++i) {
        for (int j = 0; j < n; ++j) {
            s += data[i][j];
        }
    }
    return s / (n * n);
}

Normal::~Normal() {
    for (int i = 0; i < n; ++i) {
        delete[] data[i];
    }
    delete[] data;
}
