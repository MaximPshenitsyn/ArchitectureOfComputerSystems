/*
 * ========= ФОРМУЛИРОВКА ЗАДАЧИ =========
 * У старого дона Энрике было два сына, у каждого из
 * сыновей – еще по два сына, каждый из которых имел еще по два сына.
 * Умирая, дон Энрике завещал все свое богатство правнукам в разных долях.
 * Адвокат дон Хосе выполнил задачу дележа наследства в меру своих
 * способностей. Правнуки заподозрили адвоката в укрывательстве части
 * наследства. Требуется создать многопоточное приложение, которое при
 * известных сумме завещания дона Энрике и доле каждого наследника,
 * проверяет честность адвоката. При решении использовать принцип дихотомии.
 * ========= METHOD ==========
 * Производители и потребители – это парадигма взаимодействующих
 * неравноправных потоков. Одни потоки «производят» данные, другие их
 * «потребляют». Часто такие потоки организуются в конвейер, через который
 * проходит информация. Каждый поток конвейера потребляет выход своего
 * предшественника и производит входные данные для своего последователя.
 * Другой распространенный способ организации потоков – древовидная
 * структура или сети слияния, на этом основан, в частности, метод дихотомии.
 * ========= = = = = = = = = = = =========
 */



#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>
#include <time.h>

const int arrSize = 15; // размер дерева
const int steal_percentage = 3; // процент воровства адвоката
int A[arrSize]; // дерево наследников

// функция, отвечающая за воровство адвоката
void steal(int from, int percentage) {
    int max_steal = A[from] * percentage / 100;
    if (max_steal == 0) return;
    A[from] -= random() % (max_steal);
}

// заполнение потомка, с рекурсивным вызовом для запонения
// родителя, если его наследство неизвестно
void fill(int child) {
    if (A[child] != -1) return;
    int parent = (child - 1) / 2;
    if (A[parent] == -1) {
        fill((child - 1) / 2);
    }
    int other_child = child % 2 == 0 ? child - 1 : child + 1;
    if (A[parent] == 0) {
        A[child] = A[other_child] = 0;
        return;
    }
    if (A[other_child] == -1) {
        A[child] = random() % A[parent];
        steal(child, steal_percentage);
        return;
    } else {
        A[child] = A[parent] - A[other_child];
        steal(child, steal_percentage);
    }
}

// функция потока правнуков
void *func(void *param) {
    int child = *((int*)param) + 6;
    int other_child = child % 2 == 0 ? child - 1 : child + 1;
    int parent = (child - 1) / 2;
    fill(child);        
    int h = A[child];
    printf("time = %lu ---> Great grand son %d: Heritage = %d\n", clock(), child - 6, h);
    return nullptr;
}

// функция инициализирующая дерево и потоки
// запускает потоки правнуков
void run_threads() {
    for(int i = 1; i < arrSize; i++) {
        A[i] = -1;
    }
    // A[0] = random() % 500 + 100;
    printf("Heritage = %d\n", A[0]) ;
    
    //создание четырех потоков-читателей
    pthread_t threads[8] ;
    int great_grand_sons[8];
    for (int i = 0 ; i < 8 ; i++) {
        great_grand_sons[i] = i + 1;
        pthread_create(&threads[i], NULL, func, (void*)(great_grand_sons + i));
    }
    for (int i = 0 ; i < 8 ; i++)
        pthread_join(threads[i], nullptr);
}

// основная функция приложения
int main(int argc, char* argv[]) {
    if (argc != 2) {
        printf("Incorrect params of command line! First argument must be <heritage_amount>!\n");
        return 0;
    }
    srand(time(NULL));

    // считывание переданного командной строкой значения
    A[0] = atoi(argv[1]);

    // проверка переданного значения
    if (A[0] < 0) {
    	printf("Incorrect params of command line! <heritage_amount> must be > 0!\n");
    	return 0;
    }

    // запуск потоков
    run_threads();

    // подсчёт результатов деления наследства
    int sum = 0;
    for (int i = 0 ; i < 8 ; i++) {
        printf("Great grand son %d: Heritage = %d\n", i + 1, A[i + 7]);
        sum += A[i + 7];
    }

    // вывод информации, о сумме украденного наследства
    printf("Total stolen = %d\n",A[0] - sum);

    return 0;
}



