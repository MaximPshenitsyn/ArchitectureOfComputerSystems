#!/bin/bash
 
g++ main.cpp -lpthread -o task-05

